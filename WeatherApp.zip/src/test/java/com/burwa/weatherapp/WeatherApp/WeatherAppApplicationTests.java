package com.burwa.weatherapp.WeatherApp;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@SpringBootTest
class WeatherAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
